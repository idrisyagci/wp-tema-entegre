
	
$(document).ready(function(){
    $(".mobile-menu-ackapa").click(function(){
        $(".mobile-menu").toggleClass("mobile-menu-show-hide");
    });
});